apt install python
apt install python3-pip

pip install socket
pip install requests
pip install google
pip install hashlib
pip install smtplib
